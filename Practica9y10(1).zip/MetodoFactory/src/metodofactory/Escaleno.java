/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodofactory;

/**
 *
 * @author HP
 */
public class Escaleno extends Triangulo{
     public Escaleno(int ladoA, int ladoB, int ladoC){
        super(ladoA, ladoB, ladoC);
    }

    
    public String getDescripcion() {
        return("Descripcion de Escaleno."); //To change body of generated methods, choose Tools | Templates.
    }

   
    public double getSuperficie() {
          return 3;
    }

    @Override
    public void dibujate() {
        System.out.println("Dibuja un Triangulo Escaleno."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

    

