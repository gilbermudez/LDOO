/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodofactory;

/**
 *
 * @author HP
 */
public class Principal {
    public static void main(String args[]){
        TrianguloFactoryMethod  trianguloFactori = new TrianguloFactory();
        
        Triangulo triangulo1 = trianguloFactori.crearTriangulo(5, 10, 10);
        triangulo1.dibujate();
        triangulo1.getSuperficie();
        
        
        System.out.println(triangulo1.getDescripcion()+ "\n"+ triangulo1.getSuperficie()+ "\n");
        
    
         Triangulo triangulo2 = trianguloFactori.crearTriangulo(10, 5, 10);
         triangulo2.dibujate();
         
         System.out.println(triangulo2.getDescripcion()+ "\n"+ triangulo2.getSuperficie()+ "\n");
         
         Triangulo triangulo3 = trianguloFactori.crearTriangulo(10, 10, 10);
         triangulo3.dibujate();
         
         System.out.println(triangulo3.getDescripcion()+ "\n"+ triangulo3.getSuperficie()+ "\n");
    }   
}
