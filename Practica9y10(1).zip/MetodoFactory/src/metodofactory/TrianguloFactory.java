/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodofactory;

/**
 *
 * @author HP
 */
public class TrianguloFactory implements TrianguloFactoryMethod{
    
    
    public Triangulo crearTriangulo(int ladoA, int ladoB, int ladoC) {
        if ((ladoA == ladoB)&& (ladoA == ladoC)){
        
            return new Equilatero(ladoA, ladoB, ladoC);
        }else if((ladoA!=ladoB)&&(ladoA!=ladoC)){
                return new Escaleno(ladoA,ladoB,ladoC);
                }else{
                return new Isoceles(ladoA, ladoB, ladoC);
                }
    }
}
