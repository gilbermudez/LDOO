/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodofactory;

/**
 *
 * @author HP
 */
public abstract class Triangulo {
    private int ladoA;
    private int ladoB;
    private int ladoC;
    
    public Triangulo(int ladoA, int ladoB, int ladoC){
        
    }

    public abstract String getDescripcion();
    public abstract double getSuperficie();
    public abstract void dibujate();
    
    public int getladoA(int ladoA){
        this.ladoA=ladoA;
        return this.ladoA;
    }
    
    public void setladoA(){
        
    }
    public int getladoB(int ladoB){
        this.ladoB=ladoB;
        return this.ladoB;
    }
    public void setladoB(){
        
    }
    public int getladoC(int ladoC){
        this.ladoC=ladoC;
        return this.ladoC;
    }
    public void setladoC(){
        
    }
    
}
